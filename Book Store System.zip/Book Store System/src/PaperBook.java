public class PaperBook extends Book {
    private int validQuantity;

    public PaperBook(String ISBN, String title, String author, int year, double price, int validQuantity) {
        super(ISBN, title, author, year, price);
        this.validQuantity = validQuantity;
    }

    public int getValidQuantity() {
        return validQuantity;
    }

    @Override
    public double Buy(int quantity, String email, String address) {
        if (quantity > validQuantity) {
            throw new IllegalStateException("The quantity that you want is not available!");
        } else {
            validQuantity -= quantity;
            System.out.println("Successfully processed shipping for " + address);
            return quantity * getPrice();
        }
    }
}
