public class ShowcaseBook extends Book {
    public ShowcaseBook(String ISBN, String title, String author, int year, double price) {
        super(ISBN, title, author, year, price);
    }

    @Override
    public double Buy(int quantity, String email, String address) {
        throw new UnsupportedOperationException("This book is for display only and cannot be purchased.");
    }
}
