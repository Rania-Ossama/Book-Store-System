import java.util.*;

public class Main {
    public static void main(String[] args) {
        List<Book> inventory = new ArrayList<>();

        inventory.add(new PaperBook("ISBN001", "Don Quixote", "Miguel de Cervantes", 2008, 350.0, 5));
        inventory.add(new EBook("ISBN002", "Alice's Adventures in Wonderland", "Lewis Carroll", 2020, 200.0, "PDF"));
        inventory.add(new ShowcaseBook("ISBN003", "The Adventures of Huckleberry Finn", "Mark Twain", 1890, 0.0));

        System.out.println("Quantum book store: Added 3 books to inventory.\n");

        try {
            Book book = inventory.get(0);
            double total = book.Buy(2, "test@mail.com", "Cairo, Egypt");
            System.out.println("The ISBN is " + book.getISBN());
            System.out.println("Total paid for '" + book.getTitle() + "': " + total + " EGP\n");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        try {
            Book book = inventory.get(1);
            double total = book.Buy(1, "reader@mail.com", "null");
            System.out.println("The ISBN is " + book.getISBN());
            System.out.println("Total paid for '" + book.getTitle() + "': " + total + " EGP\n");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        try {
            Book book = inventory.get(2);
            System.out.println("The ISBN is " + book.getISBN());
            book.Buy(1, "someone@mail.com", "null");
        } catch (Exception e) {
            System.out.println(e.getMessage() + "\n");
        }

        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        Iterator<Book> iterator = inventory.iterator();

        while (iterator.hasNext()) {
            Book book = iterator.next();
            if (book.isOutdated(currentYear, 10)) {
                System.out.println("Removing outdated book → " + book.getTitle());
                iterator.remove();
            }
        }

        System.out.println("\nFinal inventory contains " + inventory.size() + " book(s).");
        for (Book book : inventory) {
            System.out.println(" - " + book.getTitle() + " (" + book.getClass().getSimpleName() + ")");
        }
    }
}
