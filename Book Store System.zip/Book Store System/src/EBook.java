public class EBook extends Book {
    private String filetype;

    public EBook(String ISBN, String title, String author, int year, double price, String filetype) {
        super(ISBN, title, author, year, price);
        this.filetype = filetype;
    }

    public String getFileType() {
        return filetype;
    }

    @Override
    public double Buy(int quantity, String email, String address) {
        System.out.println("Book is delivered to this email address: " + email + " of type " + getFileType());
        return quantity * getPrice();
    }
}
